package main;

import java.io.*;
import java.util.*;
@SuppressWarnings("serial")
public class Page implements Serializable{
	
	private transient String name;
	private static final int MAX_RECORDS_PER_PAGE = 200;
	private Vector<Hashtable<String, String>> records;
	
	public Page(String name) {
		this.name = name;
		records = new Vector<Hashtable<String, String>>(MAX_RECORDS_PER_PAGE);
	}
	
	public String getName() {
		return name;
	}
	
	public static final int getMaxRecordsPerPage() {
		return MAX_RECORDS_PER_PAGE;
	}
	
	public Vector<Hashtable<String, String>> getRecords(){
		return records;
	}
	
	public boolean isFull() {
		return records.size() == MAX_RECORDS_PER_PAGE;
	}
	
	public void savePage() {
		
	}
	
}
