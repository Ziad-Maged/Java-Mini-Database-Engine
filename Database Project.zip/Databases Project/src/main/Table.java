package main;
import java.io.*;
import java.util.*;
@SuppressWarnings("serial")
public class Table implements Serializable{
	
	private String tableName;
	private Hashtable<Integer, Page> content;
	
	public Table() {
		
	}
	
	public String getTableName() {
		return tableName;
	}
	
	public Hashtable<Integer, Page> getContent(){
		return content;
	}
	
	//TODO may convert the Hash table to ArrayList or Vector
}
