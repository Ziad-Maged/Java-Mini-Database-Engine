package main;

public class SQLTerm {
	
	protected String _strTableName;
	protected String _strColumnName;
	protected String _strOperator;
	protected Object _objValue;
	
	public SQLTerm() {
		//TODO LATER
	}
	
}
